﻿
#include <iostream>
#include "Str.h"

using namespace std;

void Test(Str s) { }

int main()
{
    Str myStr = "abc";
    cout << myStr << endl;
    cout << strlen(myStr)<<endl;

    Test(myStr);

    Str t;
    t = myStr;

    Str myStr1 = "123";

    myStr1 += "defg";

    Str myStr2 = myStr1 + t;
    cout << myStr2;

    return 0;
}

