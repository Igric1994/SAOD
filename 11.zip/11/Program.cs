﻿using System;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;


namespace RegExpLab
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = " фыидо, fjbld33- 2олт?";
            Console.WriteLine(str);

            //Regex re = new Regex(@"\w+");                  //b)
            //Regex re = new Regex(@"\b[0-9]+\w+\b");        //c)
            //Regex re = new Regex(@"\w*\d\w*");             //d)
            //Regex re = new Regex(@"\w+3\b");               //e)
            //Regex re = new Regex(@"(\w)\1");               //f)
            //Regex re = new Regex(@"\b[a-zA-Z0-9]+\b");     //i)
            Regex re = new Regex(@"\b\w*[a-zA-Z]\w*\b");   //j)

            MatchCollection mc = re.Matches(str);
            foreach (var m in mc)
                Console.WriteLine(m);

            /////////////////////////////////////////////////////////////
            Console.WriteLine("--------------------");
            /////////////////////////////////////////////////////////////
            
            re = new Regex(@"(\W*)(\w+)(\W+)(\w+)(\W+)(\w+)(\W*)");
            Console.WriteLine(re.Replace("xdgc5vgjh", "$1$4$3$2$5$6$7"));

            /////////////////////////////////////////////////////////////
            Console.WriteLine("--------------------");
            /////////////////////////////////////////////////////////////
            
            string orig;
            try
            {
                using (StreamReader sr = new StreamReader("CreateDB.sql"))
                {
                    orig = sr.ReadToEnd();
                    Console.WriteLine(orig.Length);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка чтения файла: \" CreateDB.sql\"\n{0}", ex);
                return;
            }
            //l)
            
            Regex myRe = new Regex(@"\((?!\d+[,]?\s?\d?\))[^)]*\)");
            MatchCollection Mymc = myRe.Matches(orig);
            int count = 0;
            foreach (var m in Mymc)
            {
                count++;
                //Console.WriteLine(m);
            }
            Console.WriteLine(count);

            /////////////////////////////////////////////////////////////
            Console.WriteLine("--------------------");
            /////////////////////////////////////////////////////////////


            Regex go = new Regex(@"\bGO\b"); //найти все GO
            Regex set = new Regex(@"\bSET.*?ON\b");  //найти все строки SET...ON
            Regex identity = new Regex(@"IDENTITY\(1,1\)");   //найти все IDENTITY(1,1)
            Regex timestamp = new Regex(@"\btimestamp\b");   //найти все timestamp
            Regex constraint = new Regex(@"(?s)(CONSTRAINT.*?(\([a-zA-Z\[\]\s\,]+\)).*?\[PRIMARY\])"); //найти все CONSTRAINT c параметрами в $2
            Regex bdDotName = new Regex(@"\[\w*\]\.\[([a-zA-Z_]+)\]");   //найти все [].[<name>]
            Regex name = new Regex(@"\[([A-Z][a-zA-Z]+)\]\s\[([a-z]+)\]"); //найти все объявления переменных
            Regex pknonclus = new Regex(@"(?s)(PRIMARY\sKEY\s(?:NONCLUSTERED|CLUSTERED).*?(\([a-zA-Z\[\]\s\,]+\)).*?\[PRIMARY\])");
            Regex unique = new Regex(@"(?s)(UNIQUE\sNONCLUSTERED.*?(\([a-zA-Z\[\]\s\,]+\)).*?\[PRIMARY\])");
            Regex onPrim = new Regex(@"ON\s\[PRIMARY\]");
            Regex chr32 = new Regex(@"uniqueidentifier");
            Regex toText = new Regex(@"xml|ntext|nvarchar\(max\)");
            Regex toBLOB = new Regex(@"image|varbinary\(max\)");
            Regex removeSq = new Regex(@"\[([a-zA-Z]+)\]");

            //Mymc = removeSq.Matches(orig);
            //foreach (var m in Mymc)
                //Console.WriteLine(m);
            Console.WriteLine("--------");
            orig = go.Replace(orig, "");
            orig = set.Replace(orig, "");
            orig = bdDotName.Replace(orig, "$1");
            orig = name.Replace(orig, "$1 $2");
            orig = identity.Replace(orig, "AUTO_INCREMENT");
            orig = timestamp.Replace(orig, "timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
            orig = constraint.Replace(orig, "PRIMARY KEY $2");
            orig = pknonclus.Replace(orig, "PRIMARY KEY $2");
            orig = unique.Replace(orig, "UNIQUE KEY $2");
            orig = onPrim.Replace(orig, ";");
            orig = chr32.Replace(orig, "char(32)");
            orig = toText.Replace(orig, "text");
            orig = toBLOB.Replace(orig, "BLOB");
            orig = removeSq.Replace(orig, "$1");
            orig = Regex.Replace(orig, @"TEXTIMAGE_;", "");

            try
            {
                using (StreamWriter sw = new StreamWriter("MySQLfile.sql"))
                {
                    sw.Write(orig);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка сохранений в файл: \"{0}\"\n{1}", "MySQLfile.sql", ex);
                return;
            }


            //Console.Write(orig);

            Console.ReadKey();
        }
    }
}
