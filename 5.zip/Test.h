#pragma once
#include <iostream>

using namespace std;

class Test
{
public:
	static int nCount;

	Test() {
		cout << "Object test is created" << endl;
		nCount++;
		cout << "nCount: " << nCount << endl;
	}

	Test(const Test& s) {
		nCount++;
		cout << "Copy test is created" << endl;
		cout << "nCount: " << nCount << endl;
	}

	void Foo(Test t) {
		cout << "Foo() is running" << endl;
	}

	~Test() {
		cout << "Object test is destroyed" << endl;
		nCount--;
		cout << "nCount: " << nCount << endl;
	}
};



