#pragma once
#include "Test.h"

class Child : public Test
{
public:
	Child() {
		cout << "Object child is created" << endl;
	}

	~Child() {
		cout << "Object child is destroyed" << endl;
	}
};



