#pragma once
#include "Child.h"

class Aggregate
{
	Test m_objTest;
public:
	Aggregate() {
		cout << "Object aggregate is created" << endl;
	}

	~Aggregate() {
		cout << "Object aggregate is destroyed" << endl;
	}
};

template <class T> class AggregateT {
public:
	AggregateT() {
		cout << "AggregateT is created" << endl;
	}

	~AggregateT() {
		cout << "AggregateT is destroyed" << endl;
	}
};




