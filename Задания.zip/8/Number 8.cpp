﻿#include <iostream>
#include <limits>
#include "WF.h"
#include "RWF.h"

using namespace std;

int Distance(WF& wf, RWF& rwf)
{
	if (wf.Rows() != rwf.Rows())
		throw "logic_error";
	int sum = numeric_limits<int>::max();
	for (int i = 0; i <= wf.Rows(); i++)
	{
		int nsum = wf.Get(i, wf.Columns()) + rwf.Get(i, 0);
		if (nsum < sum)
			sum = nsum;
	}
	return sum;
}

char* concat_chars(const char* v, const char* u)
{
	rsize_t sv = strlen(v), su = strlen(u);
	char* concat = new char[sv + su + 1];
	for (rsize_t i = 0; i < sv + su; i++)
	{
		if (i < sv) concat[i] = v[i];
		else concat[i] = u[i - sv];
	}
	concat[sv + su] = '\0';
	return concat;
}

void CompareDist(const char* s, const char* v, const char* u)
{
	char* t = concat_chars(v, u);
	WF svwf;
	RWF surwf;
	svwf.Init(s, v);
	surwf.Init(s, u);
	int dist = Distance(svwf, surwf);
	WF stwf;
	stwf.Init(s, t);
	cout << "Parallel: " << dist << ", Direct: " << stwf.Get(stwf.Rows(), stwf.Columns()) << endl;
	delete[] t;
}

int main()
{
	WF wf;
	wf.Init("no", "ono");
	for (int i = 0; i <= wf.Rows(); i++)
	{
		for (int j = 0; j <= wf.Columns(); j++)
			cout << wf.Get(i, j) << ' ';
		cout << endl;
	}
	cout << "--------" << endl;
	RWF rwf;
	rwf.Init("no", "ono");
	for (int i = 0; i <= rwf.Rows(); i++)
	{
		for (int j = 0; j <= rwf.Columns(); j++)
			cout << rwf.Get(i, j) << ' ';
		cout << endl;
	}

	cout << "--------" << endl;
	cout << "s = AGTACCTACCGT, t = ACGTAC|GTACGT" << endl;
	CompareDist("AGTACCTACCGT", "ACGTAC", "GTACGT");
	cout << "--------" << endl;
	cout << "s = night, t = kni|ght" << endl;
	CompareDist("night", "kni", "ght");

	system("pause");
	return 0;
}
