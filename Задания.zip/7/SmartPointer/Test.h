#pragma once
#include <iostream>

class Test
{
public:
	Test()
	{
		std::cout << "Constructor!" << std::endl;
	}
	~Test()
	{
		std::cout << "Destructor!" << std::endl;
	}
};