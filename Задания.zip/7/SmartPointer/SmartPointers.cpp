﻿#include <iostream>
#include <memory>
#include "Test.h"

using namespace std;

weak_ptr<Test> wp;

int main()
{
	{
		cout << "---Block---" << endl;
		auto sp = shared_ptr<Test>(new Test);
		cout << "sp count: " << sp.use_count() << endl;
		wp = sp;
		cout << "wp count: " << wp.use_count() << endl;
		auto p = wp.lock();
		if (p)
		{
			cout << "Object is alive!" << endl;
			cout << p.use_count() << endl;
		}
		else
		{
			cout << "No owing object!" << endl;
		}
	}

	cout << "---Main---" << endl;
	auto p = wp.lock();
	if (p)
	{
		cout << "Object is alive!" << endl;
		cout << p.use_count() << endl;
	}
	else
	{
		cout << "No owing object!" << endl;
	}

	system("pause");
	return 0;
}