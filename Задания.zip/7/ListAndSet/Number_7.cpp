﻿#include <iostream>
#include <list>
#include <set>
#include "Test.h"

using namespace std;

int main()
{
	list<Test> list_test;
	cout << "---Adding 'test' objects into list---" << endl;
	for (int i = 0; i < 5; i++)
	{
		Test new_test;
		list_test.push_back(new_test);
	}
	cout << "---------------------" << endl;
	list_test.sort();

	set<Test> set_test;
	cout << "---Adding 'test' objects into set---" << endl;
	for (int i = 0; i < 2; i++)
	{
		Test new_test;
		set_test.insert(new_test);
	}
	cout << "---------------------" << endl;
	cout << set_test.size() << endl;

	cout << "---Removing items from list---" << endl;
	Test* tmp_test = new Test();
	list_test.remove(*tmp_test);
	delete tmp_test;
	cout << list_test.size() << endl;
	cout << "----------------------" << endl;



	system("pause");
	return 0;
}