#pragma once
#include <iostream>

class Test
{
private:
	int val;
public:
	Test()
	{
		val = 0;
		std::cout << "Constructor!" << std::endl;
	}
	~Test()
	{
		std::cout << "Destructor!" << std::endl;
	}
	bool operator < (const Test& test) const
	{
		return val < test.val;
	}
	bool operator == (const Test& test) const
	{
		return val == test.val;
	}
};

