﻿#include <iostream>
#include <cctype>
#include <cstdlib>

using namespace std;

inline bool charIsDigit(char* a)
{
	for (char* i = a; i < a + strlen(a); i++)
	{
		if (!isdigit(i[0])) return false;
	}
	return true;
}

enum Operations
{
	pls,
	mins,
	umn,
	delen
};

int calc(Operations op, int a, int b)
{
	switch (op)
	{
	case pls:
		return a + b;
		break;
	case mins:
		return a - b;
		break;
	case umn:
		return a * b;
		break;
	case delen:
		if (b != 0) return a / b;
		else throw "Division by zero";
		break;
	default:
		throw "Undefined operator";
		break;
	}
}

int command(const char* exp1, int a, int b)
{
	int ans = 0;
	if (strcmp(exp1, "add") == 0)
		try { ans = calc(Operations::pls, a, b); }
	catch (const char* msg) { throw msg; }
	else if (strcmp(exp1, "mul") == 0)
		try { ans = calc(Operations::umn, a, b); }
	catch (const char* msg) { throw msg; }
	else if (strcmp(exp1, "ded") == 0)
		try { ans = calc(Operations::mins, a, b); }
	catch (const char* msg) { throw msg; }
	else if (strcmp(exp1, "div") == 0)
		try { ans = calc(Operations::delen, a, b); }
	catch (const char* msg) { throw msg; }
	else throw "Invalid operator";
	return ans;
}

int main(int argc, char** argv)
{
	cout << "- ded\n+ add\n* mul\n/ div\n";
	if (argc >= 4 && charIsDigit(argv[2]) && charIsDigit(argv[3]))
	{
		const char* exp = argv[1];
		int ans = 0;
		try
		{
			ans = command(exp, atoi(argv[2]), atoi(argv[3]));
		}
		catch (const char* msg)
		{
			cout << msg << endl;
			system("pause");
			return 0;
		}
		cout << "Answer: " << ans << endl;
	}
	else
	{
		cout << "Something wrong with parametrs!" << endl;
	}

	system("pause");
	return 0;
}