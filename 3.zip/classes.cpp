﻿#include <iostream>
#include <cmath>
#include "Complex.h"

using namespace std;

int main()
{
    //Complex a(1, 2), b = 3;
    Complex c(0, 0);
    Complex v[4]{ 1,2, Complex(2,3) };
    //cout << a << ", " << b << endl;
    //cout << "res: " << a + b;
    
    for (int i = 0; i < sizeof(v) / sizeof(v[0]) - 1; i++) {
        cout << *(v + i) << ' ';
    }

    Complex* pc;
    pc = new Complex(1, 2);
    cout << "Re: " << pc->Re << " " << "Im: " << pc->Im << endl;
    delete pc;
    
    Complex* pc1 = new Complex[3];
    cout << pc1->Re;
    delete[]pc1;
    


    return 0;
}
